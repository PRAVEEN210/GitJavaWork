import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
public class Main {
    public static void main(String[] args) throws IOException {

  InputStreamReader is= new InputStreamReader(System.in);
  BufferedReader br= new BufferedReader(is);
  List<Address> ad= new ArrayList<Address>();
  List<Contact> co= new ArrayList<Contact>();
  System.out.println("Enter the number of contact-address pair:");
  int m= Integer.parseInt(br.readLine());
 
 
  for(int j=0;j<m;j++)
  {
  System.out.println("Enter the address "+(j+1)+":");
  String s=br.readLine();
  String a[]=s.split(",");
  Address z= new Address(a[1],a[0],a[2],a[3],Integer.parseInt(a[4]));
  ad.add(z);
 
  System.out.println("Enter the contact "+(j+1)+":");
  String s1= br.readLine();
  String b[]=s1.split(",");
  Contact t= new Contact(Integer.parseInt(b[0]),Integer.parseInt(b[1]),Integer.parseInt(b[2]),b[3]);
  co.add(t);
  }
 
  System.out.println("Enter the mobile of the contact to be searched:");
  int r= Integer.parseInt(br.readLine());
  int j=0;
  int check=0;
  for (Contact contact : co) {
    if(contact.getMobile()==r||contact.getAlternateNumber()==r||contact.getLandline()==r)
{
System.out.println("Contact-Address "+(j+1));
System.out.println(co.get(j).toString());
System.out.println(ad.get(j).toString());
j++;
check++;
}
}
  if(check==0)
  {
  System.out.println("No contact with mobile "+r+" found");
  }
}
}