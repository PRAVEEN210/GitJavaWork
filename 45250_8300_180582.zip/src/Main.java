import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) throws Exception, IOException {
        InputStreamReader in= new InputStreamReader(System.in);
		BufferedReader br= new BufferedReader(in);
		List<List<Integer>> li= new ArrayList<List<Integer>>();
		List<Integer> list = new ArrayList<Integer>();
		char se=0;
		System.out.println("Enter the count of booked tickets:");
		for(int j=0;j<5;j++)
		{
			System.out.println("On Day "+(j+1));
			String s= br.readLine();
			String a[]=s.split(",");
			for(int k=0;k<a.length;k++)
			{
				list.add(100-Integer.parseInt(a[k]));
			}
			li.add(list);
		}

		do
		{
			System.out.println("Enter the day to know its remaining ticket count:");
			int n=Integer.parseInt(br.readLine());
			System.out.print("Remaining tickets:[");
			System.out.print(list.get(4*n-4)+", "+list.get(4*n-3)+", "+list.get(4*n-2)+", "+list.get(4*n-1)+"]\n");
			System.out.println("Do you want to continue?(y/n)");
			se=br.readLine().charAt(0);
		}while(se=='y'||se=='Y');

	}

}