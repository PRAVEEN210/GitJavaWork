import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main{

    public static void main(String[] args) throws NumberFormatException, ParseException {
		
		Scanner scan= new Scanner(System.in);
		Map<String,Integer> map1= new HashMap<String,Integer>();
		Map<Date,Map<String,Integer>> map2= new HashMap<Date,Map<String,Integer>>();
		
		System.out.println("Enter number of show times");
		int m= Integer.parseInt(scan.nextLine());
		System.out.println("Enter details of showtimes in CSV(Show Date(dd/MM/yyyy),Show Time Interval(Eg:1PM-4PM),Tickets Booked)");
		for(int j=0;j<m;j++)
		{
			String details= scan.nextLine();
			String det[]= details.split(",");
			map1.put(det[1],Integer.parseInt(det[2]));
			map2.put(new SimpleDateFormat("dd/MM/yyyy").parse(det[0]),map1);
		}
		System.out.println("Enter a show details to find tickets booked in CSV(Show Date(dd/MM/yyyy),Show Time Interval(Eg:1PM-4PM))");
		String search=scan.nextLine();
		String details[]= search.split(",");
		if(map2.containsKey(new SimpleDateFormat("dd/MM/yyyy").parse(details[0])))
		{
			if(map1.containsKey(details[1]))
			{
				System.out.println("Tickets Booked = "+map1.get(details[1]));
			}
			else
			{
				System.out.println("No show in a particular time");
			}
			
		}
		else
		{
			System.out.println("No show in a particular time");
		}

	}

}