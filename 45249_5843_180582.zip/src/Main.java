import java.util.Map.Entry;
import java.util.Scanner;
import java.util.TreeMap;

public class Main {
   
	public static void main(String[] args) {
 
		TreeMap<String,String> tm= new TreeMap<String,String>();
		Scanner s= new Scanner(System.in);
		
		System.out.println("Enter the number of clients");
		int a= Integer.parseInt(s.nextLine());
		
		for(int j=0;j<a;j++)
		{
			System.out.println("Enter the details of the client "+(j+1));
			String clientId=s.nextLine();
			String clientName= s.nextLine();
			String email=s.nextLine();
			String passportNumber= s.nextLine();
			Client c= new Client(clientId, clientName, email, passportNumber);
			tm.put(clientId, clientName+"--"+email+"--"+passportNumber);
		}
		
		System.out.println("Client Details");
		for(Entry<String, String> m:tm.entrySet()){    
		       System.out.println(m.getKey()+"--"+m.getValue());    
		      }    
		System.out.println("Enter the id of the client to be searched");
		String search= s.nextLine();
		System.out.println("Client Details");
		if(tm.containsKey(search))
		{
			System.out.println(tm.get(search));
		}
		else
		{
			System.out.println("Client not found");
		}

	}

}