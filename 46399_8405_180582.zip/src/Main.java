import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class Main {

    public static void main(String[] args) throws ParseException {
		
		Scanner scan= new Scanner(System.in);
		List<Event> li= new ArrayList<Event>();
		
		System.out.println("Enter the number of events");
		int m= Integer.parseInt(scan.nextLine());
		if(m<=0)
		{
			System.out.println("Invalid Input");
		}
		else
		{
			System.out.println("Enter event details in CSV(Event Name,Event Date,Organizer Name)");
			for(int j=0;j<m;j++)
			{
				String event=scan.nextLine();
				String det[]= event.split(",");
				Event et= new Event(det[0], new SimpleDateFormat("dd/MM/yyyy").parse(det[1]),det[2]);
				li.add(et);
			}
			EventThread et= new EventThread();
			Map<String, Integer> count= et.eventMonths(li);
			Set<String> set= count.keySet();
			for (String string : set) {
				System.out.println(string+" = "+count.get(string)+" events");
			}
		}

	}

}