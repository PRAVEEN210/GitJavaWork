import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class EventThread {
    
	public Map<String, Integer> eventMonths(final List<Event> eventList)
	{
		Map<String,Integer> mp= new HashMap<>();
		ExecutorService executor = Executors.newSingleThreadExecutor();
		int value=1;
		for (Event event : eventList) {
	   String month= new SimpleDateFormat("MMMM").format(event.getEventDate());
		if(mp.containsKey(month))
		{
			int i=mp.get(month);
			i++;
			mp.put(month, i);
		}
		else
		{
			mp.put(month, value);
		}
		}   
		executor.shutdown();
		try {
			executor.awaitTermination(200,TimeUnit.MILLISECONDS);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	    return mp;
		
	}

}