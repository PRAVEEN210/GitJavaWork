public class BankFactory
{

    public ICICI getICICI() {
Notification ic= new ICICI();
return (ICICI) ic;
}

public HDFC getHDFC() {
Notification hd= new HDFC();
return (HDFC) hd;
}
} 
