import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
		
		Scanner s= new Scanner(System.in);       
		System.out.println("Enter the source city:");       
		String source= s.next();
		System.out.println("Enter the destination city:");
		String destination= s.next();
		System.out.println("Enter the flight\r\n1.Air India\r\n2.Indigo"); 
		int se= Integer.parseInt(s.next());
		double price;
		if(se==1) 
		{
			AirIndia ai= new AirIndia();
			price=ai.showFare(source, destination);
			System.out.println("The fare is "+price);
		}
		else if(se==2)
		{
			Indigo ig= new Indigo();
			price=ig.showFare(source, destination);
			System.out.println("The fare is "+price);
		}
		else
		{
			System.out.println("Invalid Input");
		}
	}

}