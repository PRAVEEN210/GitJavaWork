interface AirFare {         
    public Double showFare(String sourceCity, String destinationCity);
}