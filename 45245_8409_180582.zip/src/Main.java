import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws NumberFormatException, ParseException {
	
	 Scanner sc= new Scanner(System.in);
	 ArrayList<TicketBooking> li= new ArrayList<TicketBooking>();
	 System.out.println("Enter the number of bookings:");
	 int n= Integer.parseInt(sc.nextLine());
	 System.out.println("Enter the booking details:");
	 for(int j=0;j<n;j++)
	 {
		 String event= sc.nextLine();
		 String eve[]= event.split("-");
		 TicketBooking t= new TicketBooking(eve[0],Double.parseDouble(eve[1]),new SimpleDateFormat("dd/mm/yyyy").parse(eve[2]),eve[3]);
		 li.add(t);
	 }
	 System.out.println("Enter a type:\r\n1.JSON\r\n2.CSV");
	 int sl= Integer.parseInt(sc.nextLine());
	 ExportBooking eb= new ExportBooking();
	 if(sl==1)
	 {
		 System.out.println("[");
		 eb.exportJSON(li);
		 System.out.print("\r\n]");
	 }
	 else if(sl==2)
	 {
		 System.out.println("customer,price,bookingTime,stageEventShow");
		 eb.exportCSV(li);
	 }
	 else
	 {
		 System.out.println("Invalid Input");
	 }

	}

}
