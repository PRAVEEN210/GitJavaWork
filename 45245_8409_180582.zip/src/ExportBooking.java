import java.util.List;

public class ExportBooking {
    
	public void exportJSON(List<TicketBooking> bookings)
	{
		int j=bookings.size();
		//System.out.println(i);
		TicketBooking t= new TicketBooking();
		for (TicketBooking ticketBooking : bookings)
		{
			System.out.print(t.JSON(ticketBooking));
			j--;
			if(j>0)
			{
				System.out.println(",");
			}
		    
		}
	}
	public void exportCSV(List<TicketBooking> bookings)
	{
		TicketBooking t= new TicketBooking();
		for (TicketBooking ticketBooking : bookings) {
			System.out.println(t.CSV(ticketBooking));
		}
		
	}
}