import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
		
		Scanner scan= new Scanner(System.in);
		
		List<Hall> li= new ArrayList<>();
		
		System.out.println("Enter the number of halls:");
		int p= Integer.parseInt(scan.nextLine());
		
		for(int j=0;j<p;j++)
		{
			String hall=scan.nextLine();
			String det[]= hall.split(",");
			Hall h= new Hall(det[0],det[1],Double.parseDouble(det[2]),det[3]);
			li.add(h);
		}
		Hall.writeHallDetails(li);
		
	}
}