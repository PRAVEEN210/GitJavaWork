import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class Hall {
    
	private String hallName;
	private String contact;
	private double costPerDay;
	private String owner;
	
	public Hall() {
		super();
	}

	public Hall(String hallName, String contact, double costPerDay, String owner) {
		super();
		this.hallName = hallName;
		this.contact = contact;
		this.costPerDay = costPerDay;
		this.owner = owner;
	}

	public String getHallName() {
		return hallName;
	}

	public void setHallName(String hallName) {
		this.hallName = hallName;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public double getCostPerDay() {
		return costPerDay;
	}

	public void setCostPerDay(double costPerDay) {
		this.costPerDay = costPerDay;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}
	
    public static void writeHallDetails(List<Hall> halls)
	{
		FileWriter fw=null;
		try {
			fw= new FileWriter("hall.csv",false);
			for (Hall hall : halls) {
				String s= hall. hallName+","+hall.contact+","+hall.costPerDay+","+hall.owner+"\n";
				fw.write(s);
				
			}
		    } catch (IOException e) {
			e.printStackTrace();
		}
		try {
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	

}