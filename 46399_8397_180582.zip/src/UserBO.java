

	public class UserBO {
	    
		public UserBO()                    
		{
		}
		
		static void validate(User u) throws Exception          
		{
			int Count=0;
			String s2= u.getPassword();
			for(int j=0;j<s2.length();j++)                      
			{
				if(s2.charAt(j)>='0' && s2.charAt(j)<='9')
				{
					Count++;
				}
			}
			
			if(Count==0)                                  
			{
				throw new WeakPasswordException("Your password is weak");
			}
		}

	}



