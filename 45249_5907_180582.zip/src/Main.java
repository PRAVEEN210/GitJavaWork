import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
 ArrayList<String> al=new ArrayList<String>();
  
  Scanner sc=new Scanner(System.in);
  int n,n1,count;
  System.out.println("Enter the number of passengers in the list:");
  n=sc.nextInt();
  System.out.println("Enter the passengers names:");
  for(int i=0;i<n;i++)
        {
         al.add(sc.next());
        
        }
  System.out.println("Enter the number of passengers who have not arrived to the airport on time");
  n1=sc.nextInt();
  System.out.println("Enter the passenger who are not arrived airport on time:");
  for(int i=0;i<n1;i++)
        {
       al.add(sc.next());
        
        }
  
  System.out.println("New passengers list:");
 HashSet<String> hsUnique = new HashSet<String>(al);
       List<String> list = new ArrayList<String>(hsUnique);
       Collections.sort(list);
      for(String s :list)
      {
       
        count=Collections.frequency(al, s);
       if(count==1)
       {
      
       System.out.println(s);
       }
 }
 
 }
}