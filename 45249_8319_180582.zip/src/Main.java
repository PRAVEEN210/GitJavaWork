import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args)
	{
		Scanner s= new Scanner(System.in);
		List<Address> li= new ArrayList<Address>();
		System.out.println("Enter the number of users:");
		int m= Integer.parseInt(s.nextLine());
		System.out.println("Enter user address in CSV(Username,AddressLine 1,AddressLine 2,PinCode)");
		for(int j=0;j<m;j++)
		{
			String add= s.nextLine();
			String a[]= add.split(",");
			Address ad= new Address(a[0],a[1],a[2],Integer.parseInt(a[3]));
			li.add(ad);
		}
		li.sort(null);
		System.out.println("User Details:");
		for (Address address : li) {
			System.out.println(address);
		}
		
	}
}